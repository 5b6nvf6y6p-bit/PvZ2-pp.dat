document.querySelectorAll("[data-save-download]").forEach((link) => {
  link.addEventListener("click", async (event) => {
    event.preventDefault();
    const status = link.closest(".save-card").querySelector(".download-status");
    status.hidden = false;
    status.textContent = "Checking that the save file is available…";
    try {
      const response = await fetch(link.getAttribute("href"), { method: "HEAD", cache: "no-store" });
      const contentType = response.headers.get("content-type") || "";
      if (!response.ok || contentType.includes("text/html")) {
        status.textContent = "Save file not found yet. Add this exact file to the project's saves/ folder, then try again.";
        return;
      }
      const downloadResponse = await fetch(link.getAttribute("href"), { cache: "no-store" });
      if (!downloadResponse.ok) throw new Error("Download failed");
      const blob = await downloadResponse.blob();
      const url = URL.createObjectURL(blob);
      const temp = document.createElement("a");
      temp.href = url;
      temp.download = link.getAttribute("download");
      document.body.appendChild(temp);
      temp.click();
      temp.remove();
      URL.revokeObjectURL(url);
      status.textContent = "Download started. Keep a backup of your original save.";
    } catch {
      status.textContent = "Could not verify the file. If you are opening this page directly from your device, try serving the folder locally or publish it on GitHub Pages. Confirm the save exists in saves/.";
    }
  });
});
