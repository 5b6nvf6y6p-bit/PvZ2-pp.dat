# AntyPVZ2_YT

A simple, mobile-responsive, fan-made Plants vs. Zombies 2 save-sharing website with a local-first save-editor **prototype**.

> This project is not affiliated with, endorsed by, or sponsored by EA or PopCap Games. Plants vs. Zombies is the property of its respective owners.

## Project contents

- `index.html` — homepage with exactly two save download slots
- `editor.html` — PVZ2 Save Editor prototype interface
- `style.css` — responsive Peashooter-green theme
- `script.js` — checks that save files exist before downloading
- `editor.js` — local file selection and input validation; no upload
- `saves/` — place the two actual save files here

## Add your save files

Place each real save in its own directory, using the same filename `pp.dat`:

- Max Save: `saves/max/pp.dat`
- Starter Save: `saves/starter/pp.dat`

Both download buttons save the selected file to the device as `pp.dat`. Because both files have the same name, keep them in separate folders in the project. The website intentionally does not include fabricated or empty save files. If a file is missing, the homepage displays a helpful message. Never overwrite your original save without a separate backup.

## Save editor format findings

A supplied sample (`pp.dat`, 399,502 bytes) was inspected locally and parsed successfully as RTON v1:

- Header: `RTON` followed by `01 00 00 00`
- Footer: `DONE`
- Root structure: `version` and `objects`
- One `PlayerInfo` object was present.
- Its `objdata.c` field decoded to `127500` (coins) and `objdata.g` to `12750` (gems), consistent with published PVZ2 save-format references.
- The sample uses RTON compact integer tokens for these fields. The editor replaces only the two field byte ranges, keeps every other source byte unchanged, and reparses the result before offering an export.

The editor processes files in the browser and does not upload them. It refuses unsupported structures, malformed files, non-integer currency fields, and ambiguous multiple-player profiles. Export is limited to non-negative whole numbers up to 999,999,999 for both coins and gems. Values above this maximum are rejected.

**Important limitation:** no separate checksum was identified in the visible RTON header/body/footer framing, but this does not prove the game performs no additional validation. Successful parsing is not a guarantee that every game version/platform will accept an edited save. Keep an untouched backup and test cautiously.

## Run locally

Some browsers restrict file checks when an HTML file is opened directly from disk. Use a local static server for reliable testing.

### Python

From this directory, run:

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000` in your browser. Stop the server with `Ctrl+C`.

### VS Code

Install the Live Server extension, open this folder, right-click `index.html`, and choose **Open with Live Server**.

## Publish with GitHub Pages

1. Create a new repository on GitHub (for example, `AntyPVZ2_YT`).
2. Upload or push all files and folders in this project to the repository's root. Keep the `saves/` directory and filenames unchanged.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and the `/(root)` folder, then save.
6. Wait for GitHub Pages to finish deployment. Open the URL shown in the Pages settings.
7. Test both save slots on the published site. Confirm the matching `.pp.dat` files are present in `saves/`; do not commit private or sensitive saves to a public repository unless you intend them to be public.

## Privacy and safety

The editor does not upload selected files. Browser file selection grants the page access to the selected file, but this prototype only reads the file's name and size; it does not parse or transmit its contents. Keep an untouched backup before using save files from any source.
