# Starter Save

Place the real Starter Save save in this directory and name it exactly `pp.dat`.
No dummy save file is supplied. Keep an untouched backup of your original save.
