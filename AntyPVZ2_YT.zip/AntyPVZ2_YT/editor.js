(() => {
  const fileInput = document.getElementById("save-file");
  const fileInfo = document.getElementById("file-info");
  const coinsInput = document.getElementById("coins");
  const gemsInput = document.getElementById("gems");
  const validation = document.getElementById("validation-message");
  const resetButton = document.getElementById("reset-button");
  const exportButton = document.getElementById("export-button");
  const status = document.getElementById("editor-status");
  let selectedBytes = null;
  let parsedInfo = null;

  const MAX_AMOUNT = 999999999;

  function validAmount(input) {
    if (input.value.trim() === "") return false;
    const n = Number(input.value);
    return Number.isSafeInteger(n) && n >= 0 && n <= MAX_AMOUNT;
  }

  function readVarint(bytes, state, end) {
    let value = 0, shift = 0;
    for (let count = 0; count < 10; count++) {
      if (state.p >= end) throw new Error("Unexpected end while reading an RTON number.");
      const b = bytes[state.p++];
      value += (b & 0x7f) * (2 ** shift);
      if (!Number.isSafeInteger(value)) throw new Error("Number exceeds JavaScript's safe integer range.");
      if ((b & 0x80) === 0) return value;
      shift += 7;
    }
    throw new Error("Invalid or oversized RTON number.");
  }

  function encodeVarint(value) {
    const out = [];
    let n = value;
    do {
      let b = n % 128;
      n = Math.floor(n / 128);
      if (n > 0) b |= 0x80;
      out.push(b);
    } while (n > 0);
    return out;
  }

  function parseRTON(bytes) {
    if (bytes.length < 12) throw new Error("File is too small to be an RTON save.");
    if (String.fromCharCode(...bytes.slice(0, 4)) !== "RTON") throw new Error("This file does not begin with the RTON signature.");
    if (bytes[4] !== 1 || bytes[5] !== 0 || bytes[6] !== 0 || bytes[7] !== 0) throw new Error("Unsupported RTON header version.");
    const footerAt = bytes.length - 4;
    if (String.fromCharCode(...bytes.slice(footerAt)) !== "DONE") throw new Error('The expected "DONE" footer is missing.');
    const state = { p: 8, ascii: [], utf8: [] };

    function need(n) {
      if (!Number.isSafeInteger(n) || n < 0 || state.p + n > footerAt) throw new Error("RTON field extends beyond the file boundary.");
    }
    function take(n) {
      need(n);
      const value = bytes.slice(state.p, state.p + n);
      state.p += n;
      return value;
    }
    function string(utf, cache) {
      if (utf) readVarint(bytes, state, footerAt); // UTF-8 character count
      const length = readVarint(bytes, state, footerAt);
      const value = new TextDecoder("utf-8", { fatal: false }).decode(take(length));
      if (cache) (utf ? state.utf8 : state.ascii).push(value);
      return value;
    }
    function chunk(path) {
      need(1);
      const start = state.p;
      const token = bytes[state.p++];
      const node = (value, children = null) => ({ value, start, end: state.p, token, path, children });
      const rawInt = (length, signed) => {
        const part = take(length);
        let value = 0;
        for (let i = 0; i < length; i++) value += part[i] * (256 ** i);
        if (signed && value >= (2 ** (length * 8 - 1))) value -= 2 ** (length * 8);
        return value;
      };
      if (token === 0x00) return node(false);
      if (token === 0x01) return node(true);
      if (token === 0x08) return node(rawInt(1, true));
      if (token === 0x0a) return node(rawInt(1, false));
      if (token === 0x10) return node(rawInt(2, true));
      if (token === 0x12) return node(rawInt(2, false));
      if (token === 0x20) return node(rawInt(4, true));
      if (token === 0x26) return node(rawInt(4, false));
      if (token === 0x22) {
        const part = take(4);
        return node(new DataView(part.buffer, part.byteOffset, 4).getFloat32(0, true));
      }
      if (token === 0x40) return node(rawInt(8, true));
      if (token === 0x46) return node(rawInt(8, false));
      if (token === 0x42) {
        const part = take(8);
        return node(new DataView(part.buffer, part.byteOffset, 8).getFloat64(0, true));
      }
      if ([0x09,0x0b,0x11,0x13,0x21,0x27,0x41,0x47].includes(token)) return node(0);
      if (token === 0x23 || token === 0x43) return node(0.0);
      if ([0x24,0x28,0x44,0x48].includes(token)) return node(readVarint(bytes, state, footerAt));
      if ([0x25,0x29,0x45,0x49].includes(token)) {
        let n = readVarint(bytes, state, footerAt);
        if (n % 2) n = -(n + 1);
        return node(n / 2);
      }
      if (token === 0x81) return node(string(false, false));
      if (token === 0x82) return node(string(true, false));
      if (token === 0x83) {
        need(1);
        const subset = bytes[state.p++];
        if (subset === 0) return node("RTID()");
        if (subset === 2) {
          readVarint(bytes, state, footerAt);
          const len = readVarint(bytes, state, footerAt);
          const name = new TextDecoder().decode(take(len));
          const u2 = readVarint(bytes, state, footerAt);
          const u1 = readVarint(bytes, state, footerAt);
          const id = rawInt(4, false).toString(16);
          return node(`RTID(${u1}.${u2}.${id}@${name})`);
        }
        if (subset === 3) {
          readVarint(bytes, state, footerAt); const n1 = readVarint(bytes, state, footerAt);
          const s1 = new TextDecoder().decode(take(n1));
          readVarint(bytes, state, footerAt); const n2 = readVarint(bytes, state, footerAt);
          const s2 = new TextDecoder().decode(take(n2));
          return node(`RTID(${s2}@${s1})`);
        }
        throw new Error("Unknown RTON reference (RTID) subtype.");
      }
      if (token === 0x84) return node(null);
      if (token === 0x85) return parseObject(path, start, token);
      if (token === 0x86) {
        need(1);
        if (bytes[state.p++] !== 0xfd) throw new Error("Malformed RTON array start.");
        const count = readVarint(bytes, state, footerAt);
        if (count > 2000000) throw new Error("Unreasonable RTON array size.");
        const children = [];
        for (let i = 0; i < count; i++) children.push(chunk(path.concat(i)));
        need(1);
        if (bytes[state.p++] !== 0xfe) throw new Error("Malformed RTON array end.");
        return node(children.map(child => child.value), children);
      }
      if (token === 0x90) return node(string(false, true));
      if (token === 0x91) {
        const index = readVarint(bytes, state, footerAt);
        if (index >= state.ascii.length) throw new Error("Invalid RTON string-cache reference.");
        return node(state.ascii[index]);
      }
      if (token === 0x92) return node(string(true, true));
      if (token === 0x93) {
        const index = readVarint(bytes, state, footerAt);
        if (index >= state.utf8.length) throw new Error("Invalid RTON UTF-8 cache reference.");
        return node(state.utf8[index]);
      }
      if (token === 0xff) return node("__RTON_END__");
      throw new Error(`Unsupported RTON token 0x${token.toString(16).padStart(2, "0")} at byte ${start}.`);
    }
    function parseObject(path, start, token) {
      const value = {};
      const children = [];
      while (state.p < footerAt) {
        const keyNode = chunk(path.concat("<key>"));
        if (keyNode.value === "__RTON_END__") return { value, start, end: state.p, token, path, children };
        if (typeof keyNode.value !== "string") throw new Error("RTON object contains a non-string key.");
        const valueNode = chunk(path.concat(keyNode.value));
        value[keyNode.value] = valueNode.value;
        children.push({ key: keyNode.value, keyNode, valueNode });
      }
      throw new Error("RTON object is missing its end marker.");
    }

    const root = parseObject([], 8, null);
    if (state.p !== footerAt) throw new Error("Unexpected bytes remain before the RTON footer.");
    return { root, bytes, footerAt };
  }

  function child(node, key) {
    return node && node.children && node.children.find(item => item.key === key)?.valueNode;
  }

  function locateCurrencies(parsed) {
    const objectsNode = child(parsed.root, "objects");
    if (!objectsNode || !Array.isArray(objectsNode.children)) throw new Error('RTON data does not contain the expected "objects" array.');
    const profiles = [];
    for (const entry of objectsNode.children) {
      const cls = child(entry, "objclass");
      const objdata = child(entry, "objdata");
      if (cls?.value === "PlayerInfo" && objdata) profiles.push(objdata);
    }
    if (profiles.length !== 1) throw new Error(`Expected exactly one PlayerInfo profile; found ${profiles.length}. Editing is stopped to avoid changing the wrong profile.`);
    const coins = child(profiles[0], "c");
    const gems = child(profiles[0], "g");
    if (!coins || !gems || !Number.isSafeInteger(coins.value) || !Number.isSafeInteger(gems.value)) {
      throw new Error('Could not verify integer coin ("c") and gem ("g") fields in PlayerInfo.');
    }
    if (![0x24,0x28,0x44,0x48,0x20,0x26,0x08,0x0a,0x10,0x12].includes(coins.token) ||
        ![0x24,0x28,0x44,0x48,0x20,0x26,0x08,0x0a,0x10,0x12].includes(gems.token)) {
      throw new Error("Currency fields use an unrecognized integer encoding; editing is disabled for safety.");
    }
    return { coins, gems, currentCoins: coins.value, currentGems: gems.value };
  }

  function replaceRanges(bytes, ranges) {
    const sorted = ranges.slice().sort((a,b) => b.start - a.start);
    let result = bytes.slice();
    for (const r of sorted) {
      const next = new Uint8Array(result.length - (r.end - r.start) + r.replacement.length);
      next.set(result.slice(0, r.start), 0);
      next.set(r.replacement, r.start);
      next.set(result.slice(r.end), r.start + r.replacement.length);
      result = next;
    }
    return result;
  }

  function encodeCurrency(value) {
    // The sample stores both currency fields as RTON unsigned compact integers (0x24).
    return new Uint8Array([0x24, ...encodeVarint(value)]);
  }

  function updateValidation() {
    const amountsValid = validAmount(coinsInput) && validAmount(gemsInput);
    const canExport = Boolean(selectedBytes && parsedInfo && amountsValid);
    validation.classList.toggle("invalid", Boolean(
      (coinsInput.value && !validAmount(coinsInput)) ||
      (gemsInput.value && !validAmount(gemsInput))
    ));
    if (!selectedBytes) validation.textContent = "Choose a valid .pp.dat file and enter coin and gem amounts.";
    else if (!amountsValid) validation.textContent = `Enter both amounts as whole numbers from 0 to ${MAX_AMOUNT.toLocaleString("en-US")}. Values above the maximum are not allowed.`;
    else validation.textContent = "Values are valid. Export will patch only the verified coin and gem fields.";
    exportButton.disabled = !canExport;
    exportButton.title = canExport ? "Export the locally edited save." : "Choose and validate a supported save and currency values first.";
  }

  fileInput.addEventListener("change", async () => {
    selectedBytes = null;
    parsedInfo = null;
    const file = fileInput.files && fileInput.files[0];
    if (!file) {
      fileInfo.textContent = "No file selected yet.";
      status.textContent = "Select a .pp.dat file to inspect it locally.";
      updateValidation();
      return;
    }
    if (!(file.name.toLowerCase() === "pp.dat" || file.name.toLowerCase().endsWith(".pp.dat"))) {
      fileInput.value = "";
      fileInfo.textContent = "Choose a file named pp.dat or a filename ending in .pp.dat.";
      status.textContent = "File rejected: expected pp.dat or a filename ending in .pp.dat.";
      updateValidation();
      return;
    }
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const parsed = parseRTON(bytes);
      const currencies = locateCurrencies(parsed);
      selectedBytes = bytes;
      parsedInfo = { fileName: file.name, parsed, currencies };
      coinsInput.value = String(currencies.currentCoins);
      gemsInput.value = String(currencies.currentGems);
      fileInfo.textContent = `${file.name} · ${(file.size / 1024).toFixed(1)} KB · RTON v1 · parsed locally; not uploaded.`;
      status.textContent = `Format recognized. Current values detected: ${currencies.currentCoins.toLocaleString("en-US")} coins and ${currencies.currentGems.toLocaleString("en-US")} gems. No checksum field was identified in the visible RTON framing; the game may still perform additional validation.`;
    } catch (error) {
      fileInfo.textContent = `${file.name} · ${(file.size / 1024).toFixed(1)} KB`;
      status.textContent = `Editing disabled: ${error.message}`;
    }
    updateValidation();
  });

  coinsInput.addEventListener("input", updateValidation);
  gemsInput.addEventListener("input", updateValidation);

  resetButton.addEventListener("click", () => {
    fileInput.value = "";
    coinsInput.value = "";
    gemsInput.value = "";
    selectedBytes = null;
    parsedInfo = null;
    fileInfo.textContent = "No file selected yet.";
    status.textContent = "Form reset. Select a valid RTON .pp.dat file to begin.";
    updateValidation();
  });

  exportButton.addEventListener("click", () => {
    if (!selectedBytes || !parsedInfo || !validAmount(coinsInput) || !validAmount(gemsInput)) return;
    try {
      const { coins, gems } = parsedInfo.currencies;
      const edited = replaceRanges(selectedBytes, [
        { start: coins.start, end: coins.end, replacement: encodeCurrency(Number(coinsInput.value)) },
        { start: gems.start, end: gems.end, replacement: encodeCurrency(Number(gemsInput.value)) }
      ]);
      // Reparse the complete output and verify both intended values before offering it.
      const verified = parseRTON(edited);
      const after = locateCurrencies(verified);
      if (after.currentCoins !== Number(coinsInput.value) || after.currentGems !== Number(gemsInput.value)) {
        throw new Error("Post-edit verification did not match the requested values.");
      }
      const blob = new Blob([edited], { type: "application/octet-stream" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "pp.dat";
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      status.textContent = `Verified export started as pp.dat. Coin and gem fields were updated; all other source bytes were retained. Keep your original backup. Game-level compatibility cannot be guaranteed by format validation alone.`;
    } catch (error) {
      status.textContent = `Export stopped: ${error.message}`;
    }
  });

  updateValidation();
})();
